const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.EightDir,
		C3.Behaviors.bound,
		C3.Behaviors.Bullet,
		C3.Plugins.Text,
		C3.Plugins.Button,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Behaviors.EightDir.Acts.SetMaxSpeed,
		C3.Behaviors.EightDir.Acts.SetAcceleration,
		C3.Behaviors.EightDir.Acts.SetDeceleration,
		C3.Plugins.Sprite.Acts.SetAngle,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.Sprite.Acts.SetX,
		C3.Plugins.Sprite.Exps.X,
		C3.Plugins.Sprite.Acts.SetY,
		C3.Plugins.Sprite.Exps.Y,
		C3.Plugins.Sprite.Cnds.CompareY,
		C3.Plugins.Sprite.Acts.SetPos,
		C3.Plugins.System.Cnds.Every,
		C3.Plugins.System.Acts.CreateObject,
		C3.Plugins.System.Exps.random,
		C3.Behaviors.Bullet.Acts.SetAngleOfMotion,
		C3.Behaviors.Bullet.Acts.SetSpeed,
		C3.Plugins.System.Acts.SetVar,
		C3.Plugins.Sprite.Cnds.IsOverlapping,
		C3.Plugins.System.Acts.GoToLayout,
		C3.Plugins.Button.Cnds.OnClicked,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.System.Exps.dt,
		C3.Plugins.Text.Acts.SetText
	];
};
self.C3_JsPropNameTable = [
	{pista1: 0},
	{"8Direções": 0},
	{RestritoAoLayout: 0},
	{CarroJogador: 0},
	{Projétil: 0},
	{CarroInimigo: 0},
	{Sprite3: 0},
	{TxtPontos: 0},
	{ButtonReiniciar: 0},
	{pistaMenu: 0},
	{VelocidadeEstrada: 0},
	{VelocidadeInimigo: 0},
	{Pontos: 0}
];

self.InstanceType = {
	pista1: class extends self.ISpriteInstance {},
	CarroJogador: class extends self.ISpriteInstance {},
	CarroInimigo: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	TxtPontos: class extends self.ITextInstance {},
	ButtonReiniciar: class extends self.IButtonInstance {},
	pistaMenu: class extends self.ISpriteInstance {}
}